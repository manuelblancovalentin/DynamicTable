from setuptools import setup

setup(
    name='DynamicTable',
    version='0.0.4',
    packages=['DynamicTable'],
    url='http://github.com/manuelblancovalentin/DynamicTable',
    license='GPL',
    author='Manu Blanco Valentin',
    author_email='manuel.blanco.valentin@gmail.com',
    description=''
)
